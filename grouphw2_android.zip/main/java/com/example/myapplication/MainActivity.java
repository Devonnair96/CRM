package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    CRM userCRM = new CRM("Hello");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //adding Leads
        userCRM.addLead(new Lead("Lead 1"));
        userCRM.addLead(new Lead("Lead 2"));

        //adding opportunities
        userCRM.addOpporunity(new Accounts(new Lead("Opportunity 1"), createContactList("Jimmy","Jimmy@email.com","123-4567"), new ArrayList<String>(), "Finance"));
        userCRM.addOpporunity(new Accounts(new Lead("Opportunity 2"), createContactList("Timmy","Timmy@email.com","765-4321"), new ArrayList<String>(), "Medical"));

        //adding Accounts
        userCRM.addAccount(new Accounts("account 1", createContactList("John", "john@email.com", "111-2233")));
        userCRM.addAccount(new Accounts("account 2", createContactList("Jeff", "jeff@email.com", "123-1231")));

        //click to view full table
        Button FullTable = (Button) findViewById(R.id.FullTable);
        FullTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView textview = (TextView) findViewById(R.id.textView);
                textview.setText(userCRM.allInfo());
            }
        });

        Button viewcategory = (Button) findViewById(R.id.FullTable);
        viewcategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView textview = (TextView) findViewById(R.id.ViewCategory);
                textview.setText(userCRM.printFinance() + userCRM.printMedical());
            }
        });

    }
    public static ArrayList<Contacts> createContactList(String name, String email,String phonenum)
    {
        ArrayList<Contacts> ContactsList = new ArrayList<>();
        Contacts contact = new Contacts(name,phonenum,email);
        ContactsList.add(contact);

        return ContactsList;
    }


}
